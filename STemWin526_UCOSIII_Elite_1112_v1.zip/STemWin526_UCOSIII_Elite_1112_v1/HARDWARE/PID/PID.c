
#include "PID.h"
#include "includes.h"

// PID_ValueStr PID;               //����һ���ṹ�壬����ṹ���������㷨��Ҫ�õ��ĸ�������
u8	 		g_bPIDRunFlag = 0;         //PID���б�־λ��PID�㷨����һֱ�����㡣����ÿ��һ��ʱ�䣬��һ�Ρ�
u16			iTemp=0;								   //����Ҫִ�еİٷְٱ�0~100
u16			Pid_up=0;		 							 //pidִ�е�������
u16			Pid_down=0;		  					 //pidִ�е�������

u16			PID_dt = 0;
u16			S1_Counter_TempAvg = 0;
long		I_Err_Sum = 0;
float		P_out = 0;
float		I_out = 0;
float		D_out = 0;
float		Smoke_Mult = 1;

int			Auger_On;
int			Auger_Off;

	
//  ---------------------------------------  SELECT MODEL AND FEATURES	--------------------------------------------
		
int			MODEL = 1;  					//  0 = PPG (Portable)  1 = DLX, WW, SG  2 = MG  3 = XXL
		
int			Dis_C = 0;						//	0 = F  1 = C  (temp display units, Fahrenheit or Celsius)
		
//	----------------------------------------------------------------------------------------------------------------

	
	
/* ********************************************************
 �������ƣ�void PID_Init(void)                                  
 �������ܣ�PID��ʼ������                    
 ��ڲ�����                      
 ���ڲ�������
 ����˵����                                      
******************************************************** */

/*  ****************************************************************************************************  REMOVE  *****************************
void PID_Init(void)
{
    PID.uKP_Coe=0;             //����ϵ��
    PID.uKI_Coe=0;             //���ֳ���
    PID.uKD_Coe=0;             //΢�ֳ�����Ϊ0������
    PID.iPriVal=0;             //��һʱ��ֵ��Ϊ0������
    PID.iSetVal=0;             //�趨ֵ�¶�
    PID.iCurVal=0;             //ʵ��ֵ��Ϊ0������

    PID.liEkVal[2] = 0;
    PID.liEkVal[1] = 0;
    PID.liEkVal[0] = 0;

}
*/

/* ********************************************************
 �������ƣ�PID_Operation()                                  
 �������ܣ�PID����                    
��ڲ�������ǰ�¶�                      
 ���ڲ������ޣ����������U(k)��
 ����˵����U(k)+KP*[E(k)-E(k-1)]+KI*E(k)+KD*[E(k)-2E(k-1)+E(k-2)]                                      
******************************************************** */
/* *************************************************************************************************   REMOVE  ***********************************
void PID_Operation(u16 in_temp)
{
    long Temp[3] = {0};   //�м���ʱ����
    u32 PostSum = 0;     //������
    u32 NegSum = 0;      //������
	u16 i =0;
    static u16 j=0;
    static u16 k=0;

	PID.iCurVal=in_temp;
//	PID.iCurVal=210;

	if(PID.iSetVal>=PID.iCurVal) 	
	{
		j=PID.iSetVal - PID.iCurVal;
		k=100;
//	    Ctr_Hot = 1;

	}
	else 
	{
//		Ctr_Hot = 1;
		k=PID.iCurVal - PID.iSetVal;
		j=100;
	}


//		    i=PID.iSetVal - PID.iCurVal;
//			SendData(i/100+'0');
//			Time_Sum=30;			//wait 3ms
//			Wait_F1=1;
//			while(Wait_F1);
//			SendData(i%100/10+'0');
//			Time_Sum=30;			//wait 3ms
//			Wait_F1=1;
//			while(Wait_F1);
//			SendData(i%10+'0');
//			Time_Sum=30;			//wait 3ms
//			Wait_F1=1;
//			while(Wait_F1);
		   if(j<50||k<50)
		   {
			
			Temp[0] = (signed long)PID.iSetVal - (signed long)PID.iCurVal;    //ƫ��<=10,����E(k)
            // ��ֵ������λ��ע��˳�򣬷���Ḳ�ǵ�ǰ�����ֵ 
												
            PID.liEkVal[2] = PID.liEkVal[1];
            PID.liEkVal[1] = PID.liEkVal[0];
            PID.liEkVal[0] = Temp[0];
       
            Temp[0] = PID.liEkVal[0] - PID.liEkVal[1];  //E(k)-E(k-1)
			Temp[2] = PID.liEkVal[0] - PID.liEkVal[1]*2 +  PID.liEkVal[2]; //E(k)-2E(k-1)+E(k-2)

            Temp[0] = (signed long)PID.uKP_Coe * Temp[0];        //KP*[E(k)-E(k-1)]
            Temp[1] = (signed long)PID.uKI_Coe * PID.liEkVal[0]; //KI*E(k)
            Temp[2] = (signed long)PID.uKD_Coe * Temp[2]; //KD*[E(k)-2E(k-1)+E(k-2)


			Temp[0]=Temp[0]+Temp[1]+Temp[2];
			PID.iPriVal=Temp[0]+PID.iPriVal;
			
			if(PID.iPriVal>0)
			{			 
	           	iTemp=PID.iPriVal/50;
	
				if(iTemp<=Pid_down) iTemp = Pid_down;
			    if(iTemp>=Pid_up) iTemp = Pid_up;
			}
			else  iTemp=Pid_down;

			PID.iPriVal=iTemp*50;//�����´�PID���㣬iTempΪʵ��ִ������PID.iPriValΪ�������
			}
			else if (PID.iSetVal>=PID.iCurVal)	
			{
				iTemp=Pid_up;
				PID.iPriVal=0;
	            PID.liEkVal[2] = 0;
	            PID.liEkVal[1] = 0;
	            PID.liEkVal[0] = 0;
				PID.iPriVal=iTemp*50;//�����´�PID���㣬iTempΪʵ��ִ������PID.iPriValΪ�������
			}
			else 
			{
				iTemp=Pid_down;
				PID.iPriVal=0;
	            PID.liEkVal[2] = 0;
	            PID.liEkVal[1] = 0;
	            PID.liEkVal[0] = 0;
				PID.iPriVal=iTemp*50;//�����´�PID���㣬iTempΪʵ��ִ������PID.iPriValΪ�������
			}
}
*/

void PID_Ctr(u16 In_Temp,u16 Temp_Set)
{
	static int			Auger_On_Max;
	static int			Auger_On_Min;					
	static float		Auger_Ratio_Low, Auger_Ratio_High, m_slope_auger, b_offset_auger, Auger_On_Ratio;
	
	static u16			Temp_Sum;
	static u16			Num_Temp_Samples;
	static u16			Temp_Avg;
	static int			Temp_Err;
	static long			I_Err_Sum_Max;
	static int			Temp_Err_Prev=0;	
	static float		D_Err_Slope;
	static int			Auger_On_Ini;
	static float		Temp_Max;
	static float		Temp_Min;


//  Calculate equation for PWM Auger_On ratio

		if (MODEL == 3)												// XXL
		{
		Auger_On_Max = 200;
		Auger_On_Min = 0.13 * Auger_On_Max;
		Auger_Ratio_Low = 0.29;
		Auger_Ratio_High = 1.0;
		I_Err_Sum_Max = 18000;
		Temp_Max = 350;
		Temp_Min = 150;
		}	
		else if (MODEL == 2)									// MG				REWORK AND TEST FOR MAGNUM  (temp values different)
		{
		Auger_On_Max = 200;
		Auger_On_Min = 0.13 * Auger_On_Max;
		Auger_Ratio_Low = 0.25;
		Auger_Ratio_High = 1.0;
		I_Err_Sum_Max = 18000;
		Temp_Max = 600;
		Temp_Min = 160;
		}	
		else if(MODEL == 1)										// DLX, WW, SG
		{
		Auger_On_Max = 200;
		Auger_On_Min = 0.13 * Auger_On_Max;
		Auger_Ratio_Low = 0.25;
		Auger_Ratio_High = 1.0;
		I_Err_Sum_Max = 18000;
		Temp_Max = 500;
		Temp_Min = 160;
		}
		else if (MODEL == 0)									// PPG
		{
		Auger_On_Max = 200;
		Auger_On_Min = 0.10 * Auger_On_Max;		// PPG Min feed 
		Auger_Ratio_Low = 0.12;
		Auger_Ratio_High = 0.70;
		I_Err_Sum_Max = 12000;
		Temp_Max = 500;
		Temp_Min = 160;
		}

		m_slope_auger = (Auger_Ratio_High - Auger_Ratio_Low)/(Temp_Max - Temp_Min);
		b_offset_auger = Auger_Ratio_High - m_slope_auger * Temp_Max;
	

			if(S1_Counter_TempAvg>=1)  																				// 1s timer between Temperature samples
			{
				Temp_Sum = Temp_Sum + In_Temp;		
				Num_Temp_Samples++;
				S1_Counter_TempAvg = 0;
			}	
			
			if(PID_dt >= (Auger_On_Max/10))																				// Calculate P,I & D afer time >= dt  (seconds)
			{		
				Temp_Avg = Temp_Sum / Num_Temp_Samples;
				
				Temp_Err = (int)Temp_Set - (int)Temp_Avg;	
				
				if(abs(Temp_Err) <= (0.20*Temp_Set))																// Only calculate I if within % of set temp
				{											
					I_Err_Sum = I_Err_Sum + Temp_Err * (int)PID_dt;										// Ki [integral = integral + error*dt] (error/xx to slow error accumulation) 
						if(I_Err_Sum > I_Err_Sum_Max) I_Err_Sum = I_Err_Sum_Max;				// Larger number reacts slower, change in calc below	
						if(I_Err_Sum <-I_Err_Sum_Max) I_Err_Sum =-I_Err_Sum_Max;																
				}
					
				D_Err_Slope = (float)(Temp_Err - Temp_Err_Prev)/(float)PID_dt;			// Kd [Slope = (Err2-Err1)/dt]

				if(MODEL == 3)																											// *** XXL ***
				{
				P_out = 3.0 * ((float)Temp_Set/Temp_Max) * ((float)Temp_Err);
					if(P_out > 50.0) P_out = 50.0;
					if(P_out < -50.0) P_out =-50.0;
				I_out = (30.0 / I_Err_Sum_Max) * I_Err_Sum;
				}				
				else if(MODEL == 2)																									// *** MG ***
				{
//				P_out = 2.0 * (Temp_Err);
				P_out = 3.0 * ((float)Temp_Set/Temp_Max) * ((float)Temp_Err);
					if(P_out > 50.0) P_out = 50.0;
					if(P_out < -50.0) P_out =-50.0;
				I_out = (30.0 / I_Err_Sum_Max) * I_Err_Sum;
//				D_out = 40.0*(D_Err_Slope);
//					if(D_out > 100.0) D_out = 100.0;
//					if(D_out < -100.0) D_out =-100.0;
				}
				else if(MODEL == 1)																									// *** DLX, SE, WW ***
				{
//				P_out = 2.0 * (Temp_Err);
				P_out = 3.0 * ((float)Temp_Set/Temp_Max) * ((float)Temp_Err);
					if(P_out > 50.0) P_out = 50.0;
					if(P_out < -50.0) P_out =-50.0;
				I_out = (30.0 / I_Err_Sum_Max) * I_Err_Sum;
//				D_out = 40.0*(D_Err_Slope);
//					if(D_out > 100.0) D_out = 100.0;
//					if(D_out < -100.0) D_out =-100.0;
				}
				else if(MODEL == 0)																									// *** PPG ***
				{
				P_out = 3.0 * ((float)Temp_Set/Temp_Max) * ((float)Temp_Err);
					if(P_out > 50.0) P_out = 50.0;
					if(P_out < -50.0) P_out =-50.0;
				I_out = (30.0 / I_Err_Sum_Max) * I_Err_Sum;
//				D_out = 50.0*(D_Err_Slope);		
//					if(D_out > 50.0) D_out = 50.0;
//					if(D_out < -50.0) D_out =-50.0;			
				D_out = 0.0;																												// Remove if "D" used
				}
	
				Temp_Err_Prev = Temp_Err;					
					
				PID_dt = 0;
				Temp_Sum = 0;
				Num_Temp_Samples = 0;
			} 

//	Calculate auger ON and OFF time			
			Auger_On_Ratio = (m_slope_auger * (float)Temp_Set) + b_offset_auger;
			Auger_On_Ini = Auger_On_Ratio * Auger_On_Max;
			Auger_On = Auger_On_Ini + P_out + I_out + D_out;
	
			if((Auger_On < Auger_On_Min))
					Auger_On = Auger_On_Min;
			if(Auger_On > (Auger_On_Max * Auger_Ratio_High))
					Auger_On = Auger_On_Max * Auger_Ratio_High;
			
			Auger_Off = Auger_On_Max-Auger_On;
						
			
//  TEMP MODIFIER UNTIL TIMERS FIGURED OUT

			Auger_On = Auger_On / 10;
			Auger_Off = Auger_Off / 10;
			Auger_On = Auger_On * Smoke_Mult;        															// Add smoke multiplier
			Auger_Off = Auger_Off * Smoke_Mult;			

}
/*		
	if(S1_Counter_TempAvg>=1)  // 1s timer between Temperature samples 1S
	{
		Temp_Sum = Temp_Sum + in_temp;	
		//Num_Temp_Samples = ++Num_Temp_Samples;
		Num_Temp_Samples++;
		S1_Counter_TempAvg = 0;
	}	

	if(PID_dt >= (Auger_On_Max/10))	// Calculate P,I & D afer time >= dt  (seconds)PID_dt1S
	{
		Temp_Avg = Temp_Sum / Num_Temp_Samples;
		Temp_Err = (int)temp_set - (int)Temp_Avg;	
		
		if(abs(Temp_Err) <= (0.20*temp_set))																// Only calculate I if within % of set temp
		{											
			I_Err_Sum = I_Err_Sum + Temp_Err * (int)PID_dt;										// Ki [integral = integral + error*dt] (error/xx to slow error accumulation) 
			if(I_Err_Sum > I_Err_Sum_Max) I_Err_Sum = I_Err_Sum_Max;				// Larger number reacts slower, change in calc below	
			if(I_Err_Sum <-I_Err_Sum_Max) I_Err_Sum =-I_Err_Sum_Max;				//I_Err_Sum_Max????????							
		}
		
		D_Err_Slope = (float)(Temp_Err - Temp_Err_Prev)/(float)PID_dt;			// Kd [Slope = (Err2-Err1)/dt]
		
		
		P_out = 3.0 * ((float)temp_set/500.0) * ((float)Temp_Err);
		if(P_out > 50.0) P_out = 50.0;																		// Max 5 seconds for P		was 2  (6/27/18)
		if(P_out < -50.0) P_out =-50.0;
		I_out = (30.0 / I_Err_Sum_Max) * I_Err_Sum;													// Max 5 seconds for I    was 20 (6/27/18)
		//				D_out = 50.0*(D_Err_Slope);		
		//					if(D_out > 50.0) D_out = 50.0;																	// Max 5 seconds for P
		//					if(D_out < -50.0) D_out =-50.0;			
		D_out = 0.0;																												// Remove if "D" used

		Temp_Err_Prev = Temp_Err;	

		PID_dt = 0;
		Temp_Sum = 0;
		Num_Temp_Samples = 0;
	}

	// Calculate auger ON and OFF time		
	Auger_On_Ratio = (m_slope_auger * (float)temp_set) + b_offset_auger;
	Auger_On_Ini = Auger_On_Ratio * Auger_On_Max;
	Auger_On = Auger_On_Ini + P_out + I_out + D_out;

	if((Auger_On < Auger_On_Min))
			Auger_On = Auger_On_Min;
	if(Auger_On > (Auger_On_Max * Auger_Ratio_High))
			Auger_On = Auger_On_Max * Auger_Ratio_High;
	
	Auger_Off = Auger_On_Max-Auger_On;
				
	Auger_On = Auger_On * Smoke_Mult;
	Auger_Off = Auger_Off * Smoke_Mult;
}
*/

