#ifndef __ILI9325_H
#define __ILI9325_H
#include "stm32f4xx.h"
//��������IC��ILI9320����ILI9325
#define  ILI9325 

#define   BLACK                0x0000                // ��ɫ��    0,   0,   0 //
#define   BLUE                 0x001F                // ��ɫ��    0,   0, 255 //
#define   GREEN                0x07E0                // ��ɫ��    0, 255,   0 //
#define   CYAN                 0x07FF                // ��ɫ��    0, 255, 255 //
#define   RED                  0xF800                // ��ɫ��  255,   0,   0 //
#define   MAGENTA              0xF81F                // Ʒ�죺  255,   0, 255 //
#define   YELLOW               0xFFE0                // ��ɫ��  255, 255, 0   //
#define   WHITE                0xFFFF                // ��ɫ��  255, 255, 255 //
#define   NAVY                 0x000F                // ����ɫ��  0,   0, 128 //
#define   DGREEN               0x03E0                // ����ɫ��  0, 128,   0 //
#define   DCYAN                0x03EF                // ����ɫ��  0, 128, 128 //
#define   MAROON               0x7800                // ���ɫ��128,   0,   0 //
#define   PURPLE               0x780F                // ��ɫ��  128,   0, 128 //
#define   OLIVE                0x7BE0                // ����̣�128, 128,   0 //
#define   LGRAY                0xC618                // �Ұ�ɫ��192, 192, 192 //
#define   DGRAY                0x7BEF                // ���ɫ��128, 128, 128 //

//��Ļ��ת���� ���ְ��� ID[1:0]AM ����PDF�е����ö���
#define ID_AM  110
//��Ļ��ʼʱ��ʾ��ʽ��ע�⣺��IDelayʱ��ʾ��һ��������������ˢ�µ�
//��ʱ�����ֶ���ˢ�½��������  LCD_WR_REG(0x0007,0x0173);������ʾ



//Ӳ����ص��Ӻ���
//#define Bank1_LCD_D    ((u32)0x60020000)    //Disp Data ADDR
//#define Bank1_LCD_C    ((u32)0x60000000)	   //Disp Reg ADDR

#define Bank1_LCD_R       	((u32)(0x6007FFFE))
#define Bank1_LCD_D         ((u32)(0x60080000))

#define LCD_REGX     		*(__IO u16*) (Bank1_LCD_R)
#define LCD_RAMX     		*(__IO u16*) (Bank1_LCD_D)


#define Lcd_Light_ON   GPIOA->BSRR = GPIO_Pin_1;
#define Lcd_Light_OFF  GPIOA->BRR  = GPIO_Pin_1;

/* register */
/* USER_COMMAND */
#define NOP                 	0x00
#define SOFT_RESET          	0x01
#define READ_DDB_START      	0x04
#define GET_RED_CHANNEL     	0x06
#define GET_GREEN_CHANNEL   	0x07
#define GET_BLUE_CHANNEL    	0x08
#define GET_POWER_MODE      	0x0A
#define GET_ADDRESS_MODE    	0x0B
#define GET_PIXEL_FORMAT    	0x0C
#define GET_DISPLAY_MODE        0x0D
#define GET_SIGNAL_MODE         0x0E
#define GET_DIAGNOSTIC_RESULT	0x0F
#define ENTER_SLEEP_MODE        0x10
#define EXIT_SLEEP_MODE         0x11
#define ENTER_PARTIAL_MODE      0x12
#define ENTER_NOMAL_MODE        0x13
#define EXIT_INVERT_MODE        0x20
#define ENTER_INVERT_MODE       0x21
#define SET_GAMMA_CURVE         0x26
#define SET_DISPLAY_OFF         0x28
#define SET_DISPLAY_ON          0x29
#define SET_COLUMN_ADDRESS      0x2A
#define SET_PAGE_ADDRESS        0x2B
#define WRITE_MEMORY_START      0x2C
#define WITE_LUT                0x2D
#define READ_MEMORY_START       0x2E
#define SET_PARTIAL_AREA        0x30
#define SET_SCROLL_AREA         0x33
#define SET_TEAR_OFF            0x34
#define SET_TEAR_ON             0x35
#define SET_ADDRESS_MODE        0x36
#define SET_SCROLL_START        0x37
#define EXTI_IDLE_MODE          0x38
#define ENTER_IDLE_MODE         0x39
#define SET_PIXEL_FORMAT        0x3A
#define WRITE_MEMORY_CONTINUE   0x3C
#define READ_MEMORY_CONTINUE    0x3E
#define SET_TEAR_SCANLINE       0x44
#define GET_SCANLINE            0x45
#define READ_DDB_CONTINUE       0xA8


/* MANUFACTURER  COMMAND */
#define DISPLAY_REFRESH_CONTROL            0x6F
#define MANUFACTURER_COMMAND_PROTECT       0xB0
#define LOW_POWER_MODE                     0xB1
#define FRAME_MEMORY_SETTING               0xB3
#define ECC_ERROR_COUNT                    0xB5
#define DSI_CONTROL                        0xB6
#define MDDI_CONTROL                       0xB7
#define BACKLIGHT_CONTROL1                 0xB8
#define BACKLIGHT_CONTROL2                 0xB9
#define BACKLIGHT_CONTROL3                 0xBA
#define RESIZING_CONTROL                   0xBD
#define DEVICE_CODE_READ                   0xBF
#define PANEL_DRIVING_SETTING1             0xC0
#define PANEL_DRIVING_SETTING2             0xC1
#define DISPLAY_VTIME_SETTING              0xC2
#define PANEL_DRIVING_SETTING3             0xC4
#define OUTLINE_SHARPENING_CONTROL         0xC6
#define PANEL_DRIVING_SETTING4             0xC7
#define GAMMA_SETTING_A                    0xC8
#define GAMMA_SETTING_B                    0xC9
#define GAMMA_SETTING_C                    0xCA
#define POWER_SETTING1                     0xD0
#define POWER_SETTING2                     0xD1
#define POWER_SETTING3                     0xD3
#define VPLVLVNLVL_SETTING                 0xD5
#define VCOMDC_SETTING1                    0xDE
#define NVM_ACCESS_CONTROL                 0xE0
#define SET_DDB_ERITE_CONTTROL             0xE1
#define VCOMDC_SETTING2                    0xE6
#define READ_MODE_IN_FOR_DBI               0xF5
#define READ_MODE_OUT_FOR_DBI              0xF6
#define VDC_SEL_SETTING                    0xFA

#define VERTICAL_DISPLAY     0x00
#define HORIZON_DISPLAY			 0x01

//Lcd��ʼ������ͼ����ƺ���
void Lcd_Configuration(void);
void Lcd_Initialize(void);
void lcd_command_init(void);
void lcd_display_dir(uint8_t display_mode);
void lcd_clear(uint16_t x_start,
 	           uint16_t x_end, 
               uint16_t y_start, 
               uint16_t y_end, 
			   uint16_t color);
void lcd_data_bus_test(void);
void lcd_set_cursor(uint16_t x, uint16_t y);
uint16_t lcd_read_point(uint16_t x, uint16_t y);
void lcd_on(void);
void lcd_off(void);
void lcd_scan_dir(uint8_t dir);
void lcd_draw_point(uint16_t x,
					uint16_t y,
					uint16_t color);
void lcd_fast_draw_point(uint16_t x,
						 uint16_t y,
						 uint16_t color);
void lcd_fill(uint16_t x_start,
			  uint16_t x_end,
			  uint16_t y_start,
			  uint16_t y_end,
			  uint16_t color);
//void LCD_WR_REG(u16 Index,u16 CongfigTemp);
//Lcd�߼����ƺ���

void Lcd_ColorBox(u16 x,u16 y,u16 xLong,u16 yLong,u16 Color);
void DrawPixel(u16 x, u16 y, int Color);
 u16 GetPoint( u16 x, u16 y);
void BlockWrite(unsigned int Xstart,unsigned int Xend,unsigned int Ystart,unsigned int Yend);
void LCD_Fill_Pic(u16 x, u16 y,u16 pic_H, u16 pic_V, const unsigned char* pic);

#endif


