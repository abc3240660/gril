#include "xfs5152.h"
#include "key.h"
#include "seahelper.h"

extern u8 Data_Head[];
extern u8 speaker_val;

u8 XFS_Write_Data(u8 *dat,u16 len)
{
  u16 i=0;
  for(i=0;i<len;i++)
  {
    put_one_char(dat[i]);
		
		if (6 == i) {
			u8 msg[64];
			u8 rdy = XFS_RDY;
			u8 key = KEY0;
			sprintf(msg,"xfs5152 rdy = %d key = %d",rdy,key);
			LCD_ShowString(100,550,lcddev.width,lcddev.height,24,msg);
		}
  }
  return 0;
}
void XFS_Play(u8 *CQdata)
{
//  u8 Data_Head[60];
  u16 len=0;  
  len =strlen(CQdata);
  Data_Head[0] = 0xFD ;
  Data_Head[1] = 0x00 ;
  Data_Head[2] = len+2;
  Data_Head[3] = 0x01 ;
  Data_Head[4] = 0x00;
  memcpy(&Data_Head[5], CQdata, len);
  XFS_Write_Data(Data_Head,5+len);
}

void XFS_Play1(u8 *CQdata)
{
  u16 len=0;  
	
	memset(Data_Head, 0, 256);
	
  len =strlen(CQdata);
  Data_Head[0] = 0xFD;
  Data_Head[1] = 0x00;
  Data_Head[2] = len+2;
  Data_Head[3] = 0x01;
  Data_Head[4] = 0x01;// GBK 
  memcpy(&Data_Head[5], CQdata, len);
	
	for (int i=0;i<len+5;i++) {
		put_one_char(Data_Head[i]);
		delay_us(1000);
	}		
}

void switch_people(u8 index)
{
	u8 data_len = 10;
	u8 data[10] = {0xFD, 0x00, 0x07, 0x01, 0x01, 0x5B, 0x6D, 0x35, 0x33, 0x5D};
	
	if (index != 0) {
		data[8] = 0x30 + index;
	} else {
		data[2] = 0x06;
		data[7] = 0x33;
		data[8] = 0x5d;
		data_len = 9;
	}
	for (int i=0;i<data_len;i++) {
		put_one_char(data[i]);
		delay_us(1000);
	}
	
	delay_ms(200);
}

void xfs5152_reset(void)
{
  // XFS5152CE reset
	XFS_RST = 1;
	delay_ms(100);
	XFS_RST = 0;
	delay_ms(100);
	XFS_RST = 1;
	delay_ms(100);
	
	if ((speaker_val >= 0) && (speaker_val <= 5))
		switch_people(speaker_val);
	delay_ms(200);
}