#ifndef __XFS_H__
#define __XFS_H__
#include "sys.h"
#include "usart.h"
#include <string.h>
u8 XFS_Write_Data(u8 *dat,u16 len);
void XFS_Play(u8 *CQdata);
#endif