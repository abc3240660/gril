#include "ft5206.h"
#include "touch.h"
#include "ctiic.h"
#include "usart.h"
#include "delay.h" 
#include "string.h"
#include "lcd.h"
#include "text.h"

typedef unsigned char BYTE;
typedef unsigned short USHORT;

/*--------------------------------------------------------------*/
/* FUNC:                                                        */
/*   Send I2C start signal                                      */
/* PARA:                                                        */
/*   NONE                                                       */
/* RETN:                                                        */
/*   NONE                                                       */
/*--------------------------------------------------------------*/
void i2c_start_sig(void)
{
    CT_SDA_OUT();

    CT_IIC_SDA = 1;
    CT_IIC_SCL = 1;
    delay_us(10);

    CT_IIC_SDA = 0;
    delay_us(10);

    CT_IIC_SCL = 0;
    delay_us(10);
}

/*--------------------------------------------------------------*/
/* FUNC:                                                        */
/*   Send I2C stop signal                                       */
/* PARA:                                                        */
/*   NONE                                                       */
/* RETN:                                                        */
/*   NONE                                                       */
/*--------------------------------------------------------------*/
void i2c_stop_sig(void)
{
    CT_SDA_OUT();

    CT_IIC_SDA = 0;
    CT_IIC_SCL = 0;
    delay_us(10);

    CT_IIC_SDA = 1;
    delay_us(10);

    CT_IIC_SCL = 1;
    delay_us(10);
}

/*--------------------------------------------------------------*/
/* FUNC:                                                        */
/*   Send one byte through I2C protocol                         */
/* PARA:                                                        */
/*   bySend - byte data to be send                              */
/* RETN:                                                        */
/*   NONE                                                       */
/*--------------------------------------------------------------*/
void i2c_send_byte(BYTE bySend)
{
    BYTE index;

    CT_SDA_OUT();

    for(index=0; index<8; index++) {
        CT_IIC_SDA = (bySend&0x80)>>7;
        bySend <<= 1;
        delay_us(10);

        CT_IIC_SCL = 1;
        delay_us(10);

        CT_IIC_SCL = 0;
        delay_us(10);
    }
}

/*--------------------------------------------------------------*/
/* FUNC:                                                        */
/*   Read one byte through I2C procotol                         */
/* PARA:                                                        */
/*   NONE                                                       */
/* RETN:                                                        */
/*   return received data                                       */
/*--------------------------------------------------------------*/
BYTE i2c_read_byte(BYTE mode)
{
    BYTE index, byrecv;

    CT_SDA_IN();
    delay_us(10);

    byrecv = 0;
    for(index=0; index<8; index++) {
        CT_IIC_SCL = 1;
        delay_us(10);

        byrecv <<= 1;
        if(CT_READ_SDA) {
            byrecv++;
        }

        CT_IIC_SCL = 0;
        delay_us(10);
    }

    CT_SDA_OUT();
    delay_us(10);

	if (0 == mode) {
		CT_IIC_SDA = 0;
		CT_IIC_SCL = 0;
		delay_us(10);

		CT_IIC_SCL = 1;
		delay_us(10);
		CT_IIC_SCL = 0;
		delay_us(10);
	} else {
	    CT_IIC_SDA = 0;
		CT_IIC_SCL = 1;
		delay_us(10);

		CT_IIC_SCL = 1;
		delay_us(10);
		CT_IIC_SCL = 0;
		delay_us(10);
	}

    return byrecv;
}

/*--------------------------------------------------------------*/
/* FUNC:                                                        */
/*   Wait I2C ack signal                                        */
/* PARA:                                                        */
/*   NONE                                                       */
/* RETN:                                                        */
/*   If success, return 0; else return 1;                       */
/*--------------------------------------------------------------*/
BYTE i2c_wait_ack(void)
{
    BYTE ret;

    CT_SDA_OUT();

    CT_IIC_SDA = 1;
    delay_us(10);
    CT_SDA_IN();

    CT_IIC_SCL = 1;
    delay_us(10);

    if(CT_READ_SDA) {
        delay_ms(1);
        ret = 1;
    }
    else {
        ret = 0;
    }
    CT_SDA_OUT();

    CT_IIC_SCL = 0;
    delay_us(10);

    return ret;
}

/*--------------------------------------------------------------*/
/* FUNC:                                                        */
/*   Read FT6206 register                                       */
/* PARA:                                                        */
/*   addr - register address                                    */
/*   pbuf - data buff                                           */
/* RETN:                                                        */
/*   If success, return 0; else return 1;                       */
/*--------------------------------------------------------------*/
BYTE ft6206_read_reg(BYTE addr, BYTE *pbuf)
{
    BYTE value, ret;

    i2c_start_sig();
    i2c_send_byte(FT_CMD_WR);
    ret = i2c_wait_ack();
    if( 0 != ret ) {
        return 1;
    }

    i2c_send_byte(addr);
    ret = i2c_wait_ack();
    if( 0 != ret ) {
        return 1;
    }
    i2c_stop_sig();

    i2c_start_sig();
    i2c_send_byte(FT_CMD_RD);
    ret = i2c_wait_ack();
    if( 0 != ret ) {
        return 1;
    }

    value = i2c_read_byte(0);
    i2c_stop_sig();

    *pbuf = value;

    return 0;
}

BYTE ft6206_read_regs(BYTE addr, BYTE *pbuf, BYTE len)
{
		BYTE i = 0;
    BYTE value, ret;

    i2c_start_sig();
    i2c_send_byte(FT_CMD_WR);
    ret = i2c_wait_ack();
    if( 0 != ret ) {
        return 1;
    }

    i2c_send_byte(addr);
    ret = i2c_wait_ack();
    if( 0 != ret ) {
        return 1;
    }
    i2c_stop_sig();

    i2c_start_sig();
    i2c_send_byte(FT_CMD_RD);
    ret = i2c_wait_ack();
    if( 0 != ret ) {
        return 1;
    }

	for (i=0; i<len; i++) {
		if ((len-1) == i) {
			value = i2c_read_byte(1);
		} else {
			value = i2c_read_byte(0);
		}
		*(pbuf+i) = value;
	}
    
    i2c_stop_sig();

    return 0;
}

/*--------------------------------------------------------------*/
/* FUNC:                                                        */
/*   Write FT6206 register                                      */
/* PARA:                                                        */
/*   addr - register address                                    */
/*   vals - register data                                       */
/* RETN:                                                        */
/*   If success, return 0; else return 1;                       */
/*--------------------------------------------------------------*/
BYTE ft6206_write_reg(BYTE addr, BYTE vals)
{
    BYTE ret;

    i2c_start_sig();
    i2c_send_byte(FT_CMD_WR);
    ret = i2c_wait_ack();
    if( 0 != ret ) {
        return 1;
    }

    i2c_send_byte(addr);
    ret = i2c_wait_ack();
    if( 0 != ret ) {
        return 1;
    }

    i2c_send_byte(vals);
    ret = i2c_wait_ack();
    if( 0 != ret ) {
        return 1;
    }
    i2c_stop_sig();

    return 0;
}

/*--------------------------------------------------------------*/
/* FUNC:                                                        */
/*   Initialize FT6206 touch screen                             */
/* PARA:                                                        */
/*   NONE                                                       */
/* RETN:                                                        */
/*   If success, return 0; else return 1;                       */
/*--------------------------------------------------------------*/
BYTE FT5206_Init(void)
{
		u8 touch_state=8;
	
		BYTE vers[2] = {0};
	
    GPIO_InitTypeDef GPIO_InitStructure;
    BYTE verHigh, verLow, ret;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

#if 1	
		/* touch INT */
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;//WK_UP��Ӧ����PA0
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//��ͨ����ģʽ damon add
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100M damon add
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP ;//����
		GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIOA0
#endif		

    delay_ms(10);
		
		touch_state = FT_INT;

    /* switch device to working mode */
    ret = ft6206_write_reg(0x00, 0x00);
    if(0 != ret) {
        return 1;
    }
    //ft6206_read_reg(0x00, &verHigh);

    /* switch device to polling mode */
    ret = ft6206_write_reg(0xA4, 0x00);
    if(0 != ret) {
        return 1;
    }
    //ft6206_read_reg(0xA4, &verHigh);

    /* set device touch threshold */
    ret = ft6206_write_reg(0x80, 0x16);
    if(0 != ret) {
        return 1;
    }
#if 0
    ft6206_read_reg(0x80, &verHigh);

    /* read firmware version register */
    ret = ft6206_read_reg(0xA1, &verHigh);
    if(0 != ret) {
        return 1;
    }
    ret = ft6206_read_reg(0xA2, &verLow);
    if(0 != ret) {
        return 1;
    }
    if( (0x30 != verHigh) || (0xF8 != verLow) ) {
        return 1;
    }
#endif

	ft6206_read_regs(0xA1, &vers[0], 2);

    return 0;
}

u8 FT5206_WR_Reg(u16 reg,u8 *buf,u8 len)
{
	u8 i;
	u8 ret=0;
	CT_IIC_Start();	 
	CT_IIC_Send_Byte(FT_CMD_WR);	//????? 	 
	CT_IIC_Wait_Ack(); 	 										  		   
	CT_IIC_Send_Byte(reg&0XFF);   	//???8???
	CT_IIC_Wait_Ack();  
	for(i=0;i<len;i++)
	{	   
    	CT_IIC_Send_Byte(buf[i]);  	//???
		ret=CT_IIC_Wait_Ack();
		if(ret)break;  
	}
    CT_IIC_Stop();					//????????	    
	return ret; 
}
//?FT5206??????
//reg:???????
//buf:??????
//len:?????			  
void FT5206_RD_Reg(u16 reg,u8 *buf,u8 len)
{
	u8 i; 
 	CT_IIC_Start();	
 	CT_IIC_Send_Byte(FT_CMD_WR);   	//????? 	 
	CT_IIC_Wait_Ack(); 	 										  		   
 	CT_IIC_Send_Byte(reg&0XFF);   	//???8???
	CT_IIC_Wait_Ack();  
 	CT_IIC_Start();  	 	   
	CT_IIC_Send_Byte(FT_CMD_RD);   	//?????		   
	CT_IIC_Wait_Ack();	   
	for(i=0;i<len;i++)
	{	   
    	buf[i]=CT_IIC_Read_Byte(i==(len-1)?0:1); //???	  
	} 
    CT_IIC_Stop();//????????     
}

uint8_t FT6206_Read_Reg2(uint8_t *pbuf,uint32_t len)
{
	
	int8_t i=0;

	CT_IIC_Start();
	CT_IIC_Send_Byte(FT_CMD_WR);
	CT_IIC_Wait_Ack();	
	
	CT_IIC_Send_Byte(0);
	CT_IIC_Wait_Ack();	
  CT_IIC_Stop();
  
	CT_IIC_Start();
	CT_IIC_Send_Byte(FT_CMD_RD);
	CT_IIC_Wait_Ack();	
	
	for(i=0;i<len;i++)
	{
		if(i==(len-1))  *(pbuf+i)=CT_IIC_Read_Byte(0);
		else            *(pbuf+i)=CT_IIC_Read_Byte(1);
	}		
	CT_IIC_Stop();
  
	return 0;
}

u8 a2,buf2[10];
volatile static u16 touchX2=0,touchY2=0,lastY2=0;

int GUI_TOUCH_X_MeasureX2(void)
{
	FT6206_Read_Reg2((uint8_t*)&buf2, 7);

	if ((buf2[2]&0x0f) == 1)
	{
		touchX2 = (s16)(buf2[5] & 0x0F)<<8 | (s16)buf2[6];
		touchY2 = (s16)(buf2[3] & 0x0F)<<8 | (s16)buf2[4];
		if(touchY2==0)
			touchX2=0;	
	}
	else
	{
		touchY2 =0;
		touchX2 =0;		
	}
	return touchY2;
}

//???FT5206???
//???:0,?????;1,????? 

const u16 FT5206_TPX_TBL[5]={FT_TP1_REG,FT_TP2_REG,FT_TP3_REG,FT_TP4_REG,FT_TP5_REG};

int GUI_TOUCH_X_MeasureX3(void)
{
	u8 buf[4];
	u8 i=0;
	u8 res=0;
	u8 temp;
	static u8 t=0;//??????,????CPU???   
	u8 mode = 0;
	
	t++;
	
		FT5206_RD_Reg(FT_REG_NUM_FINGER,&mode,1);//????????  
		if((mode&0XF)&&((mode&0XF)<6))
		{
					FT5206_RD_Reg(FT5206_TPX_TBL[0],buf,4);	//??XY??? 
					if(tp_dev.touchtype&0X01)//??
					{
						tp_dev.y[i]=((u16)(buf[0]&0X0F)<<8)+buf[1];
						tp_dev.x[i]=((u16)(buf[2]&0X0F)<<8)+buf[3];
					}else
					{
						tp_dev.x[i]=480-(((u16)(buf[0]&0X0F)<<8)+buf[1]);
						tp_dev.y[i]=((u16)(buf[2]&0X0F)<<8)+buf[3];
					}
					
					if ((tp_dev.x[i] < 480)&&(tp_dev.y[i] < 800)) {
						mode = 1;
					}
		}
}

//?????(??????)
//mode:0,????.
//???:??????.
//0,?????;1,?????
BYTE xxflag = 0;
u8 FT52060_Scan(u8 mode)
{
    USHORT xres, yres;
    BYTE point, byval, ret;
    BYTE strdis[32];

	u16 xx = 0;
	u16 yy = 0;
	
	u8 buf[4];
	u8 i=0;
	u8 res=0;
	u8 temp[5] = {0};
	static u8 t=0;//??????,????CPU???   
	t++;
	if((t%10)==0||t<10)//???,???10?CTP_Scan?????1?,????CPU???
	{
		
			ft6206_read_regs(0x02, &temp[0], 5);
		
		  /* only response one point touch */
      point = temp[0] & 0x0F;
      if( 1 != point ) {
          return 0;
      }
			
			if (0 == FT_INT) {
				xx=480 - (((u16)(temp[3]&0X0F)<<8)+temp[4]);
				yy=(((u16)(temp[1]&0X0F)<<8)+temp[2]);
				
				printf("get\r\n");
			} else {
				printf("get\r\n");
			}
				
#if 0
        /* read touch point number */
        ret = ft6206_read_reg(0x02, &point);
        if( 0 != ret ) {
            return 0;
        }

        /* only response one point touch */
        point &= 0x0F;
        if( 1 != point ) {
            return 0;
        }
				
				printf("get\r\n");

        /* read touch point coordinate value */
        ret = ft6206_read_reg(0x03, &byval);
        if( 0 != ret ) {
            return 0;
        }
        xres = byval & 0x0F;

        ret = ft6206_read_reg(0x04, &byval);
        if( 0 != ret ) {
            return 0;
        }
        xres = (xres<<4) + byval;

        ret = ft6206_read_reg(0x05, &byval);
        if( 0 != ret ) {
            return 0;
        }
        yres = byval & 0x0F;

        ret = ft6206_read_reg(0x06, &byval);
        if( 0 != ret ) {
            return 0;
        }
        yres = (yres<<4) + byval;
#endif  
    }
	if(t>240)t=10;//???10????
	return res;
}

//ɨ�败����(���ò�ѯ��ʽ)
//mode:0,����ɨ��.
//����ֵ:��ǰ����״̬.
//0,�����޴���;1,�����д���
u8 FT5206_Scan(u8 mode)
{
	u8 buf[4];
	u8 i=0;
	u8 res=0;
	u8 temp;
	static u8 t=0;//���Ʋ�ѯ���,�Ӷ�����CPUռ����   
	t++;
	if((t%10)==0||t<10)//����ʱ,ÿ����10��CTP_Scan�����ż��1��,�Ӷ���ʡCPUʹ����
	{
		ft6206_read_regs(FT_REG_NUM_FINGER, &mode, 1);
		//FT5206_RD_Reg(FT_REG_NUM_FINGER,&mode,1);//��ȡ�������״̬  
		if (0 == FT_INT) {
			if((mode&0XF)&&((mode&0XF)<6))
			{
				temp=0XFF<<(mode&0XF);//����ĸ���ת��Ϊ1��λ��,ƥ��tp_dev.sta���� 
				tp_dev.sta=(~temp)|TP_PRES_DOWN|TP_CATH_PRES; 
				for(i=0;i<5;i++)
				{
					if(tp_dev.sta&(1<<i))	//������Ч?
					{
						ft6206_read_regs(FT5206_TPX_TBL[i],buf,4);	//��ȡXY����ֵ 
						//FT5206_RD_Reg(FT5206_TPX_TBL[i],buf,4);	//��ȡXY����ֵ 
						if(tp_dev.touchtype&0X01)//����
						{
							tp_dev.y[i]=((u16)(buf[0]&0X0F)<<8)+buf[1];
							tp_dev.x[i]=((u16)(buf[2]&0X0F)<<8)+buf[3];
						}else
						{
							tp_dev.x[i]=480-(((u16)(buf[2]&0X0F)<<8)+buf[3]);
							tp_dev.y[i]=((u16)(buf[0]&0X0F)<<8)+buf[1];
						} 

						if (0 == FT_INT) {
							printf("get\r\n");
						} else {
							printf("get\r\n");
						}
				
						if((buf[0]&0XF0)!=0X80)tp_dev.x[i]=tp_dev.y[i]=0;//������contact�¼�������Ϊ��Ч
						//printf("x[%d]:%d,y[%d]:%d\r\n",i,tp_dev.x[i],i,tp_dev.y[i]);
					}			
				} 
				res=1;
				if(tp_dev.x[0]==0 && tp_dev.y[0]==0)mode=0;	//���������ݶ���0,����Դ˴�����
				t=0;		//����һ��,��������������10��,�Ӷ����������
			}
		}
	}
	if((mode&0X1F)==0)//�޴����㰴��
	{ 
		if(tp_dev.sta&TP_PRES_DOWN)	//֮ǰ�Ǳ����µ�
		{
			tp_dev.sta&=~(1<<7);	//��ǰ����ɿ�
		}else						//֮ǰ��û�б�����
		{ 
			tp_dev.x[0]=0xffff;
			tp_dev.y[0]=0xffff;
			tp_dev.sta&=0XE0;	//�������Ч���	
		}	 
	} 	
	if(t>240)t=10;//���´�10��ʼ����
	return res;
}

#if 0
#include "ft5206.h"
#include "touch.h"
#include "ctiic.h"
#include "usart.h"
#include "delay.h" 
#include "string.h" 

//////////////////////////////////////////////////////////////////////////////////	 
//������ֻ��ѧϰʹ�ã�δ���������ɣ��������������κ���;
//ALIENTEK STM32������
//7����ݴ�����-FT5206 ��������	   
//����ԭ��@ALIENTEK
//������̳:www.openedv.com
//��������:2014/11/30
//�汾��V1.0
//��Ȩ���У�����ؾ���
//Copyright(C) �������������ӿƼ����޹�˾ 2014-2024
//All rights reserved									  
////////////////////////////////////////////////////////////////////////////////// 
 
 
//��FT5206д��һ������
//reg:��ʼ�Ĵ�����ַ
//buf:���ݻ�������
//len:д���ݳ���
//����ֵ:0,�ɹ�;1,ʧ��.
u8 FT5206_WR_Reg(u16 reg,u8 *buf,u8 len)
{
	u8 i;
	u8 ret=0;
	CT_IIC_Start();	 
	CT_IIC_Send_Byte(FT_CMD_WR);	//����д���� 	 
	CT_IIC_Wait_Ack(); 	 										  		   
	CT_IIC_Send_Byte(reg&0XFF);   	//���͵�8λ��ַ
	CT_IIC_Wait_Ack();  
	for(i=0;i<len;i++)
	{	   
    	CT_IIC_Send_Byte(buf[i]);  	//������
		ret=CT_IIC_Wait_Ack();
		if(ret)break;  
	}
    CT_IIC_Stop();					//����һ��ֹͣ����	    
	return ret; 
}
//��FT5206����һ������
//reg:��ʼ�Ĵ�����ַ
//buf:���ݻ�������
//len:�����ݳ���			  
void FT5206_RD_Reg(u16 reg,u8 *buf,u8 len)
{
	u8 i; 
 	CT_IIC_Start();	
 	CT_IIC_Send_Byte(FT_CMD_WR);   	//����д���� 	 
	CT_IIC_Wait_Ack(); 	 										  		   
 	CT_IIC_Send_Byte(reg&0XFF);   	//���͵�8λ��ַ
	CT_IIC_Wait_Ack();  
 	CT_IIC_Start();  	 	   
	CT_IIC_Send_Byte(FT_CMD_RD);   	//���Ͷ�����		   
	CT_IIC_Wait_Ack();	   
	for(i=0;i<len;i++)
	{	   
    	buf[i]=CT_IIC_Read_Byte(i==(len-1)?0:1); //������	  
	} 
    CT_IIC_Stop();//����һ��ֹͣ����     
}

uint8_t FT6206_Read_Reg2(uint8_t *pbuf,uint32_t len)
{
	
	int8_t i=0;

	CT_IIC_Start();
	CT_IIC_Send_Byte(FT_CMD_WR);
	CT_IIC_Wait_Ack();	
	
	CT_IIC_Send_Byte(0);
	CT_IIC_Wait_Ack();	
  CT_IIC_Stop();
  
	CT_IIC_Start();
	CT_IIC_Send_Byte(FT_CMD_RD);
	CT_IIC_Wait_Ack();	
	
	for(i=0;i<len;i++)
	{
		if(i==(len-1))  *(pbuf+i)=CT_IIC_Read_Byte(0);
		else            *(pbuf+i)=CT_IIC_Read_Byte(1);
	}		
	CT_IIC_Stop();
  
	return 0;
}

u8 a2,buf2[10];
volatile static u16 touchX2=0,touchY2=0,lastY2=0;

int GUI_TOUCH_X_MeasureX2(void)
{
	FT6206_Read_Reg2((uint8_t*)&buf2, 7);

	if ((buf2[2]&0x0f) == 1)
	{
		touchX2 = (s16)(buf2[5] & 0x0F)<<8 | (s16)buf2[6];
		touchY2 = (s16)(buf2[3] & 0x0F)<<8 | (s16)buf2[4];
		if(touchY2==0)
			touchX2=0;	
	}
	else
	{
		touchY2 =0;
		touchX2 =0;		
	}
	return touchY2;
}

//��ʼ��FT5206������
//����ֵ:0,��ʼ���ɹ�;1,��ʼ��ʧ�� 
u8 FT5206_Init(void)
{
	u8 temp[2]; 

	CT_IIC_Init();      	//��ʼ����������I2C����  
//	FT_RST=0;				//��λ
//	delay_ms(20);
// 	FT_RST=1;				//�ͷŸ�λ		    
#if 0
	delay_ms(50);  	
	temp[0]=0;
	FT5206_WR_Reg(FT_DEVIDE_MODE,temp,1);	//������������ģʽ 
	FT5206_WR_Reg(FT_ID_G_MODE,temp,1);		//��ѯģʽ 
#endif
	temp[0]=22;								//������Чֵ��22��ԽСԽ����	
	FT5206_WR_Reg(FT_ID_G_THGROUP,temp,1);	//���ô�����Чֵ
#if 0
	temp[0]=12;								//�������ڣ�����С��12�����14
	FT5206_WR_Reg(FT_ID_G_PERIODACTIVE,temp,1); 
	//��ȡ�汾�ţ��ο�ֵ��0x3003
#endif
	FT5206_RD_Reg(FT_ID_G_LIB_VERSION,&temp[0],2);  
	if(temp[0]==0X30&&temp[1]==0X03)//�汾:0X3003
	{
		printf("CTP ID:%x\r\n",((u16)temp[0]<<8)+temp[1]);
		return 0;
	} 
	return 1;
}
const u16 FT5206_TPX_TBL[5]={FT_TP1_REG,FT_TP2_REG,FT_TP3_REG,FT_TP4_REG,FT_TP5_REG};

int GUI_TOUCH_X_MeasureX3(void)
{
	u8 buf[4];
	u8 i=0;
	u8 res=0;
	u8 temp;
	static u8 t=0;//���Ʋ�ѯ���,�Ӷ�����CPUռ����   
	t++;
	u8 mode = 0;
	
		FT5206_RD_Reg(FT_REG_NUM_FINGER,&mode,1);//��ȡ�������״̬  
		if((mode&0XF)&&((mode&0XF)<6))
		{
					FT5206_RD_Reg(FT5206_TPX_TBL[0],buf,4);	//��ȡXY����ֵ 
					if(tp_dev.touchtype&0X01)//����
					{
						tp_dev.y[i]=((u16)(buf[0]&0X0F)<<8)+buf[1];
						tp_dev.x[i]=((u16)(buf[2]&0X0F)<<8)+buf[3];
					}else
					{
						tp_dev.x[i]=480-(((u16)(buf[0]&0X0F)<<8)+buf[1]);
						tp_dev.y[i]=((u16)(buf[2]&0X0F)<<8)+buf[3];
					}
					
					if ((tp_dev.x[i] < 480)&&(tp_dev.y[i] < 800)) {
						mode = 1;
					}
		}
}

//ɨ�败����(���ò�ѯ��ʽ)
//mode:0,����ɨ��.
//����ֵ:��ǰ����״̬.
//0,�����޴���;1,�����д���
u8 FT5206_Scan(u8 mode)
{
	u16 xx = 0;
	u16 yy = 0;
	
	u8 buf[4];
	u8 i=0;
	u8 res=0;
	u8 temp;
	static u8 t=0;//���Ʋ�ѯ���,�Ӷ�����CPUռ����   
	t++;
	if((t%10)==0||t<10)//����ʱ,ÿ����10��CTP_Scan�����ż��1��,�Ӷ���ʡCPUʹ����
	{
//		GUI_TOUCH_X_MeasureX3();
#if 1
		FT5206_RD_Reg(FT_REG_NUM_FINGER,&mode,1);//��ȡ�������״̬  
		if((mode&0XF)&&((mode&0XF)<6))
		{
			temp=0XFF<<(mode&0XF);//����ĸ���ת��Ϊ1��λ��,ƥ��tp_dev.sta���� 
			tp_dev.sta=(~temp)|TP_PRES_DOWN|TP_CATH_PRES; 
			for(i=0;i<5;i++)
			{
				if(tp_dev.sta&(1<<i))	//������Ч?
				{
					FT5206_RD_Reg(FT5206_TPX_TBL[i],buf,4);	//��ȡXY����ֵ 
					
					xx = ((u16)(buf[0]&0X0F)<<8)+buf[1]; 
					yy = ((u16)(buf[2]&0X0F)<<8)+buf[3];
					if ((xx > 50) && (xx < 400) && (yy > 50) && (yy < 700)) {
						temp = 0;
					}
						
					if(tp_dev.touchtype&0X01)//����
					{
						tp_dev.y[i]=((u16)(buf[0]&0X0F)<<8)+buf[1];
						tp_dev.x[i]=((u16)(buf[2]&0X0F)<<8)+buf[3];
					}else
					{
						tp_dev.x[i]=480-(((u16)(buf[0]&0X0F)<<8)+buf[1]);
						tp_dev.y[i]=((u16)(buf[2]&0X0F)<<8)+buf[3];
					}  
					if((buf[0]&0XF0)!=0X80)tp_dev.x[i]=tp_dev.y[i]=0;//������contact�¼�������Ϊ��Ч
					//printf("x[%d]:%d,y[%d]:%d\r\n",i,tp_dev.x[i],i,tp_dev.y[i]);
				}			
			} 
			res=1;
			if(tp_dev.x[0]==0 && tp_dev.y[0]==0)mode=0;	//���������ݶ���0,����Դ˴�����
			t=0;		//����һ��,��������������10��,�Ӷ����������
		}
#endif
	}
	if((mode&0X1F)==0)//�޴����㰴��
	{ 
		if(tp_dev.sta&TP_PRES_DOWN)	//֮ǰ�Ǳ����µ�
		{
			tp_dev.sta&=~(1<<7);	//��ǰ����ɿ�
		}else						//֮ǰ��û�б�����
		{ 
			tp_dev.x[0]=0xffff;
			tp_dev.y[0]=0xffff;
			tp_dev.sta&=0XE0;	//�������Ч���	
		}	 
	} 	
	if(t>240)t=10;//���´�10��ʼ����
	return res;
}

#endif
 



























