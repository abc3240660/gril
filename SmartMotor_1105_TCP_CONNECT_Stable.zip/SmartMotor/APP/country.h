#ifndef __COUNTRY_NAME__
#define __COUNTRY_NAME__

#define CNTY_LEN 64

typedef struct{
	char shortName[5];
	char cnName[32];
	char enName[CNTY_LEN];
}COUNTRY;

typedef struct {
	char eastDgr[20];
	char eastMin[5];
	char eastSec[5];
	char westDgr[5];
	char westMin[5];
	char westSec[5];
	char allDgr[5];
}DEST;
#endif