#ifndef __SEAHELPER_H
#define __SEAHELPER_H
#include "sys.h"
#include "includes.h" 	   	 
#include "common.h"     	 

#define SETTING_SECTOR_ADDR	 	188 + 792

u8 sea_helper_play(void);
u8 main_ui(void);
u8 country_btn_create(void);
u8 drection_btn_create(void);
u8 t9_input_create(u8 btn_index);
u8 play_ui_create(void);
u8 allCountrylist_btn_create(void);
u8 next_allow_check();
void make_test_data(void);
u8 main_ui_imo(void);
u8 mode_sel(void);
u8 main_ui_welcom(void);
void voice_play(void);
	
#endif /* SEAHELPER */